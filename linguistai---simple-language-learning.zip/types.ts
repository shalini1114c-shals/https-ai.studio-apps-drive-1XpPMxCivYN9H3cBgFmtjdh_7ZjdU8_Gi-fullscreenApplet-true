
export enum Language {
  Spanish = 'Spanish',
  French = 'French',
  German = 'German',
  Japanese = 'Japanese',
  Korean = 'Korean',
  Italian = 'Italian'
}

export enum LearningGoal {
  Travel = 'Travel',
  Work = 'Work',
  Casual = 'Casual',
  Academic = 'Academic'
}

export interface UserProgress {
  selectedLanguage: Language;
  goal: LearningGoal;
  xp: number;
  streak: number;
  level: number;
  completedLessons: string[];
  lastActive: string;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  pronunciation?: string;
  example?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  translation?: string;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  type: 'vocabulary' | 'grammar' | 'conversation' | 'pronunciation';
  xpReward: number;
}
