
import { Language, LearningGoal, Lesson } from './types';

export const INITIAL_LESSONS: Lesson[] = [
  { id: 'v1', title: 'Basic Greetings', description: 'Learn how to say hello and goodbye.', type: 'vocabulary', xpReward: 10 },
  { id: 'g1', title: 'Present Tense', description: 'The foundation of daily conversation.', type: 'grammar', xpReward: 15 },
  { id: 'p1', title: 'Vowel Sounds', description: 'Master the core sounds of the language.', type: 'pronunciation', xpReward: 20 },
  { id: 'c1', title: 'At the Cafe', description: 'Practice ordering your favorite drink.', type: 'conversation', xpReward: 20 },
  { id: 'v2', title: 'Family & Home', description: 'Common words for people and objects.', type: 'vocabulary', xpReward: 10 },
  { id: 'g2', title: 'Articles & Nouns', description: 'Mastering the gender and count of things.', type: 'grammar', xpReward: 15 },
  { id: 'p2', title: 'Common Phrases', description: 'Practice the flow and rhythm of key sentences.', type: 'pronunciation', xpReward: 20 },
  { id: 'g3', title: 'Personal Pronouns', description: 'I, you, he, she, and more.', type: 'grammar', xpReward: 15 },
  { id: 'g4', title: 'Adjectives & Colors', description: 'Learn how to describe the world around you.', type: 'grammar', xpReward: 15 },
  { id: 'g5', title: 'The Past Tense', description: 'How to talk about things that happened yesterday.', type: 'grammar', xpReward: 15 },
  { id: 'g6', title: 'Common Prepositions', description: 'Describing where things are located.', type: 'grammar', xpReward: 15 },
  { id: 'g7', title: 'Asking Questions', description: 'Master who, what, where, when, and why.', type: 'grammar', xpReward: 15 },
  { id: 'g8', title: 'Sentence Structure', description: 'Learn the fundamental word order to build complete thoughts.', type: 'grammar', xpReward: 15 },
];

export const LANGUAGE_FLAGS: Record<Language, string> = {
  [Language.Spanish]: '🇪🇸',
  [Language.French]: '🇫🇷',
  [Language.German]: '🇩🇪',
  [Language.Japanese]: '🇯🇵',
  [Language.Korean]: '🇰🇷',
  [Language.Italian]: '🇮🇹',
};
