
import { GoogleGenAI, Type } from "@google/genai";
import { Language, Flashcard } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getTutorResponse = async (
  language: Language, 
  userMessage: string, 
  history: { role: 'user' | 'model', text: string }[]
) => {
  const model = 'gemini-3-flash-preview';
  
  const systemInstruction = `You are a friendly language tutor for ${language}. 
    Keep responses short, engaging, and suitable for beginners. 
    Always provide a translation in English in brackets. 
    Encourage the user to practice specific vocabulary related to their last message.`;

  const contents = [
    ...history.map(h => ({ role: h.role, parts: [{ text: h.text }] })),
    { role: 'user' as const, parts: [{ text: userMessage }] }
  ];

  try {
    const response = await ai.models.generateContent({
      model,
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });
    return response.text || "Sorry, I'm having trouble connecting to my brain right now.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error connecting to tutor.";
  }
};

export const generateVocabulary = async (language: Language, topic: string): Promise<Flashcard[]> => {
  const model = 'gemini-3-flash-preview';
  
  try {
    const response = await ai.models.generateContent({
      model,
      contents: `Generate 5 flashcards for learning ${language} about the topic: ${topic}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              front: { type: Type.STRING, description: "The word in the target language" },
              back: { type: Type.STRING, description: "The English translation" },
              pronunciation: { type: Type.STRING, description: "Phonetic pronunciation" },
              example: { type: Type.STRING, description: "A simple example sentence in the target language" },
            },
            required: ["id", "front", "back", "pronunciation"]
          }
        }
      }
    });

    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Vocab Generation Error:", error);
    return [];
  }
};

export const getGrammarExplanation = async (language: Language, topic: string) => {
    const model = 'gemini-3-flash-preview';
    try {
        const response = await ai.models.generateContent({
            model,
            contents: `Explain the grammar concept "${topic}" in ${language} for a beginner. Provide 3 clear examples with translations. Use markdown formatting.`,
        });
        return response.text;
    } catch (error) {
        return "Failed to load explanation.";
    }
}

export const evaluatePronunciation = async (language: Language, phrase: string, audioBase64: string, mimeType: string) => {
  const model = 'gemini-3-flash-preview';
  try {
    const response = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          {
            text: `Analyze the user's pronunciation of the phrase "${phrase}" in ${language}. 
            Compare their speech to a native speaker. 
            Respond with a JSON object containing:
            1. 'score': a number from 0 to 100.
            2. 'feedback': a short encouraging sentence.
            3. 'tips': an array of 2-3 specific phonetic improvement tips.
            Be honest but supportive.`
          },
          {
            inlineData: {
              data: audioBase64,
              mimeType: mimeType
            }
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            feedback: { type: Type.STRING },
            tips: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["score", "feedback", "tips"]
        }
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Pronunciation Analysis Error:", error);
    return null;
  }
};
