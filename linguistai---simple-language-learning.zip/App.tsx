
import React, { useState, useEffect } from 'react';
import { Language, LearningGoal, UserProgress, Lesson } from './types';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import Navbar from './components/Navbar';
import FlashcardMode from './components/FlashcardMode';
import GrammarMode from './components/GrammarMode';
import ChatMode from './components/ChatMode';
import PronunciationMode from './components/PronunciationMode';
import Profile from './components/Profile';

const App: React.FC = () => {
  const [progress, setProgress] = useState<UserProgress | null>(null);
  const [activeTab, setActiveTab] = useState('home');
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);

  // Load progress from local storage
  useEffect(() => {
    const saved = localStorage.getItem('linguist_progress');
    if (saved) {
      setProgress(JSON.parse(saved));
    }
  }, []);

  // Save progress
  useEffect(() => {
    if (progress) {
      localStorage.setItem('linguist_progress', JSON.stringify(progress));
    }
  }, [progress]);

  const handleOnboarding = (lang: Language, goal: LearningGoal) => {
    const initialProgress: UserProgress = {
      selectedLanguage: lang,
      goal,
      xp: 0,
      streak: 1,
      level: 1,
      completedLessons: [],
      lastActive: new Date().toISOString(),
    };
    setProgress(initialProgress);
  };

  const handleLessonComplete = () => {
    if (!progress || !activeLesson) return;

    const newXp = progress.xp + activeLesson.xpReward;
    const newLevel = Math.floor(newXp / 100) + 1;
    const isNewLesson = !progress.completedLessons.includes(activeLesson.id);

    setProgress({
      ...progress,
      xp: newXp,
      level: newLevel,
      completedLessons: isNewLesson 
        ? [...progress.completedLessons, activeLesson.id] 
        : progress.completedLessons,
    });
    
    setActiveLesson(null);
  };

  if (!progress) {
    return <Onboarding onComplete={handleOnboarding} />;
  }

  // Handle active lesson views
  if (activeLesson) {
    switch (activeLesson.type) {
      case 'vocabulary':
        return (
          <FlashcardMode 
            lesson={activeLesson} 
            language={progress.selectedLanguage} 
            onBack={() => setActiveLesson(null)} 
            onComplete={handleLessonComplete}
          />
        );
      case 'grammar':
        return (
          <GrammarMode 
            lesson={activeLesson} 
            language={progress.selectedLanguage} 
            onBack={() => setActiveLesson(null)} 
            onComplete={handleLessonComplete}
          />
        );
      case 'conversation':
        return (
          <ChatMode 
            language={progress.selectedLanguage} 
            onBack={() => setActiveLesson(null)} 
            onComplete={handleLessonComplete}
          />
        );
      case 'pronunciation':
        return (
          <PronunciationMode 
            lesson={activeLesson} 
            language={progress.selectedLanguage} 
            onBack={() => setActiveLesson(null)} 
            onComplete={handleLessonComplete}
          />
        );
    }
  }

  // Handle "Chat" tab special case (Always available tutoring)
  if (activeTab === 'chat') {
    return (
      <ChatMode 
        language={progress.selectedLanguage} 
        onBack={() => setActiveTab('home')} 
        onComplete={() => {
            // Give periodic XP for chatting
            setProgress(p => p ? {...p, xp: p.xp + 5} : p);
            setActiveTab('home');
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <main className="flex-1 overflow-hidden flex flex-col">
        {activeTab === 'home' && (
          <Dashboard progress={progress} onSelectLesson={setActiveLesson} />
        )}
        {activeTab === 'profile' && <Profile progress={progress} />}
      </main>
      <Navbar currentTab={activeTab} setTab={setActiveTab} progress={progress} />
    </div>
  );
};

export default App;
