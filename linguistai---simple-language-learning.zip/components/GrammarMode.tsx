
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Loader2, Sparkles, CheckCircle2 } from 'lucide-react';
import { Language, Lesson } from '../types';
import { getGrammarExplanation } from '../services/geminiService';

interface GrammarModeProps {
  lesson: Lesson;
  language: Language;
  onBack: () => void;
  onComplete: () => void;
}

const GrammarMode: React.FC<GrammarModeProps> = ({ lesson, language, onBack, onComplete }) => {
  const [explanation, setExplanation] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadExplanation = async () => {
      setLoading(true);
      const data = await getGrammarExplanation(language, lesson.title);
      setExplanation(data);
      setLoading(false);
    };
    loadExplanation();
  }, [language, lesson]);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col p-6 max-w-md mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={onBack} className="p-2 hover:bg-white rounded-xl shadow-sm">
          <ArrowLeft size={24} className="text-slate-600" />
        </button>
        <h2 className="text-xl font-bold font-outfit text-slate-900 flex-1">{lesson.title}</h2>
      </div>

      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="h-full flex flex-col items-center justify-center space-y-4">
            <Loader2 className="animate-spin text-indigo-600" size={40} />
            <p className="text-slate-500 font-medium">Preparing grammar guide...</p>
          </div>
        ) : (
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 animate-in fade-in duration-700">
            <div className="flex items-center gap-2 text-indigo-600 mb-6">
              <Sparkles size={20} />
              <span className="font-bold text-sm uppercase tracking-widest">Mastering {language} Grammar</span>
            </div>
            
            <div className="prose prose-slate max-w-none">
                <div className="whitespace-pre-wrap text-slate-700 leading-relaxed font-medium">
                  {explanation}
                </div>
            </div>

            <div className="mt-8 p-6 bg-indigo-50 rounded-2xl border border-indigo-100">
                <h4 className="font-bold text-indigo-900 mb-4">Quick Recap</h4>
                <ul className="space-y-3">
                    <li className="flex gap-2 text-sm font-medium text-indigo-700">
                        <CheckCircle2 size={18} className="shrink-0" />
                        Understand the basic structure
                    </li>
                    <li className="flex gap-2 text-sm font-medium text-indigo-700">
                        <CheckCircle2 size={18} className="shrink-0" />
                        Observe common exceptions
                    </li>
                    <li className="flex gap-2 text-sm font-medium text-indigo-700">
                        <CheckCircle2 size={18} className="shrink-0" />
                        Apply in conversation
                    </li>
                </ul>
            </div>
          </div>
        )}
      </div>

      <button
        onClick={onComplete}
        disabled={loading}
        className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg shadow-lg shadow-indigo-100 mt-8 mb-4 disabled:opacity-50"
      >
        Complete Lesson
      </button>
    </div>
  );
};

export default GrammarMode;
