
import React, { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Mic, Square, Volume2, Sparkles, Loader2, Trophy, ArrowRight, RefreshCw } from 'lucide-react';
import { Language, Lesson } from '../types';
import { evaluatePronunciation } from '../services/geminiService';

interface PronunciationModeProps {
  lesson: Lesson;
  language: Language;
  onBack: () => void;
  onComplete: () => void;
}

const PRONUNCIATION_PHRASES: Record<Language, string[]> = {
  [Language.Spanish]: ["Hola, ¿cómo estás?", "Me gustaría un café, por favor.", "La cuenta, por favor.", "Mucho gusto en conocerte."],
  [Language.French]: ["Bonjour, comment ça va ?", "Je voudrais un café, s'il vous plaît.", "L'addition, s'il vous plaît.", "Ravi de vous rencontrer."],
  [Language.German]: ["Guten Tag, wie geht es Ihnen?", "Ich möchte einen Kaffee, bitte.", "Die Rechnung, bitte.", "Freut mich, Sie kennenzulernen."],
  [Language.Japanese]: ["こんにちは、お元気ですか？", "コーヒーを一つお願いします。", "お会計をお願いします。", "はじめまして。"],
  [Language.Korean]: ["안녕하세요, 어떻게 지내세요?", "커피 한 잔 주세요.", "계산서 주세요.", "만나서 반가워요."],
  [Language.Italian]: ["Buongiorno, come va?", "Vorrei un caffè, per favore.", "Il conto, per favore.", "Piacere di conoscerti."],
};

const PronunciationMode: React.FC<PronunciationModeProps> = ({ lesson, language, onBack, onComplete }) => {
  const [currentPhraseIdx, setCurrentPhraseIdx] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [feedback, setFeedback] = useState<{ score: number; feedback: string; tips: string[] } | null>(null);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  
  const phrases = PRONUNCIATION_PHRASES[language] || PRONUNCIATION_PHRASES[Language.Spanish];
  const currentPhrase = phrases[currentPhraseIdx];

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = async () => {
        const audioBlob = new Blob(chunks, { type: 'audio/webm' });
        await handleAudioAnalysis(audioBlob);
      };

      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
      setFeedback(null);
    } catch (err) {
      console.error("Microphone access denied", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorder) {
      mediaRecorder.stop();
      setIsRecording(false);
      setIsAnalyzing(true);
    }
  };

  const handleAudioAnalysis = async (blob: Blob) => {
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onloadend = async () => {
      const base64Audio = (reader.result as string).split(',')[1];
      const result = await evaluatePronunciation(language, currentPhrase, base64Audio, 'audio/webm');
      setFeedback(result);
      setIsAnalyzing(false);
    };
  };

  const speak = () => {
    const utterance = new SpeechSynthesisUtterance(currentPhrase);
    const langMap: Record<Language, string> = {
      [Language.Spanish]: 'es-ES',
      [Language.French]: 'fr-FR',
      [Language.German]: 'de-DE',
      [Language.Japanese]: 'ja-JP',
      [Language.Korean]: 'ko-KR',
      [Language.Italian]: 'it-IT',
    };
    utterance.lang = langMap[language] || 'en-US';
    window.speechSynthesis.speak(utterance);
  };

  const handleNext = () => {
    if (currentPhraseIdx < phrases.length - 1) {
      setCurrentPhraseIdx(prev => prev + 1);
      setFeedback(null);
    } else {
      onComplete();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col p-6 max-w-md mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-10">
        <button onClick={onBack} className="p-2 hover:bg-white rounded-xl shadow-sm transition-all">
          <ArrowLeft size={24} className="text-slate-600" />
        </button>
        <div className="flex-1 px-6">
          <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-indigo-600 transition-all duration-500"
              style={{ width: `${((currentPhraseIdx + 1) / phrases.length) * 100}%` }}
            />
          </div>
        </div>
        <span className="text-sm font-bold text-slate-400">{currentPhraseIdx + 1}/{phrases.length}</span>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center space-y-8">
        <div className="text-center space-y-4 w-full">
          <div className="flex items-center justify-center gap-2 text-indigo-600">
            <Sparkles size={20} />
            <span className="font-bold text-sm uppercase tracking-widest">Speak the phrase</span>
          </div>
          <h2 className="text-3xl font-bold font-outfit text-slate-900 px-4 leading-tight">{currentPhrase}</h2>
          
          <button 
            onClick={speak}
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-full font-bold text-sm hover:bg-indigo-100 transition-colors"
          >
            <Volume2 size={18} />
            Listen to native speaker
          </button>
        </div>

        {/* Recording Visualizer / Button */}
        <div className="relative flex flex-col items-center">
          {isRecording && (
            <div className="absolute inset-0 -m-4 bg-red-500/20 rounded-full animate-ping" />
          )}
          <button
            onMouseDown={startRecording}
            onMouseUp={stopRecording}
            onTouchStart={startRecording}
            onTouchEnd={stopRecording}
            disabled={isAnalyzing}
            className={`relative z-10 w-24 h-24 rounded-full flex items-center justify-center transition-all shadow-xl shadow-red-100 ${
              isRecording 
                ? 'bg-red-500 text-white scale-110' 
                : isAnalyzing ? 'bg-slate-200 text-slate-400' : 'bg-white border-4 border-red-50 text-red-500 hover:border-red-100'
            }`}
          >
            {isAnalyzing ? <Loader2 size={32} className="animate-spin" /> : 
             isRecording ? <Square size={32} /> : <Mic size={32} />}
          </button>
          <p className="mt-4 text-xs font-bold text-slate-400 uppercase tracking-widest">
            {isRecording ? "Listening..." : isAnalyzing ? "Analyzing..." : "Hold to speak"}
          </p>
        </div>

        {/* Feedback Section */}
        {feedback && (
          <div className="w-full bg-white rounded-3xl p-6 shadow-sm border border-slate-100 animate-in zoom-in duration-300">
            <div className="flex items-start justify-between mb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Trophy size={20} className={feedback.score > 80 ? "text-yellow-500" : "text-slate-400"} />
                  <span className="text-2xl font-bold text-slate-900 font-outfit">{feedback.score}/100</span>
                </div>
                <p className="text-sm font-medium text-slate-500">{feedback.feedback}</p>
              </div>
              <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                feedback.score > 80 ? "bg-emerald-100 text-emerald-600" : "bg-orange-100 text-orange-600"
              }`}>
                {feedback.score > 80 ? "Excellent" : "Keep practicing"}
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Pro Tips</p>
              <ul className="space-y-1.5">
                {feedback.tips.map((tip, i) => (
                  <li key={i} className="text-xs font-medium text-slate-700 flex gap-2">
                    <span className="text-indigo-400">•</span>
                    {tip}
                  </li>
                ))}
              </ul>
            </div>

            <button
              onClick={handleNext}
              className="mt-6 w-full py-3 bg-indigo-600 text-white rounded-2xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all shadow-md shadow-indigo-100"
            >
              <span>{currentPhraseIdx < phrases.length - 1 ? "Next Phrase" : "Finish Lesson"}</span>
              <ArrowRight size={16} />
            </button>
          </div>
        )}
      </div>

      {!feedback && !isRecording && !isAnalyzing && (
         <div className="text-center opacity-50 flex items-center justify-center gap-2 text-slate-400 text-sm italic">
            <RefreshCw size={14} />
            Records as you hold down the button
         </div>
      )}
    </div>
  );
};

export default PronunciationMode;
