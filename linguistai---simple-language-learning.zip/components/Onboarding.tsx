
import React, { useState } from 'react';
import { Language, LearningGoal } from '../types';
import { LANGUAGE_FLAGS } from '../constants';
import { ArrowRight, Globe, Target } from 'lucide-react';

interface OnboardingProps {
  onComplete: (lang: Language, goal: LearningGoal) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [selectedLang, setSelectedLang] = useState<Language | null>(null);
  const [selectedGoal, setSelectedGoal] = useState<LearningGoal | null>(null);

  const languages = Object.values(Language);
  const goals = Object.values(LearningGoal);

  const handleNext = () => {
    if (step === 1 && selectedLang) setStep(2);
    else if (step === 2 && selectedGoal && selectedLang) {
      onComplete(selectedLang, selectedGoal);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col p-6 max-w-md mx-auto">
      <div className="flex-1 flex flex-col justify-center">
        {step === 1 ? (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="space-y-2">
              <div className="w-12 h-12 bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600 mb-4">
                <Globe size={28} />
              </div>
              <h1 className="text-3xl font-bold font-outfit text-slate-900">What do you want to learn?</h1>
              <p className="text-slate-500">Choose a language to start your journey.</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {languages.map((lang) => (
                <button
                  key={lang}
                  onClick={() => setSelectedLang(lang)}
                  className={`p-4 rounded-2xl border-2 transition-all text-left flex items-center gap-3 ${
                    selectedLang === lang 
                      ? 'border-indigo-600 bg-indigo-50' 
                      : 'border-slate-100 hover:border-indigo-200'
                  }`}
                >
                  <span className="text-2xl">{LANGUAGE_FLAGS[lang]}</span>
                  <span className="font-semibold text-slate-700">{lang}</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-in slide-in-from-right duration-500">
            <div className="space-y-2">
              <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 mb-4">
                <Target size={28} />
              </div>
              <h1 className="text-3xl font-bold font-outfit text-slate-900">What's your goal?</h1>
              <p className="text-slate-500">We'll personalize your learning path.</p>
            </div>

            <div className="space-y-3">
              {goals.map((goal) => (
                <button
                  key={goal}
                  onClick={() => setSelectedGoal(goal)}
                  className={`w-full p-5 rounded-2xl border-2 transition-all text-left flex items-center justify-between ${
                    selectedGoal === goal 
                      ? 'border-indigo-600 bg-indigo-50' 
                      : 'border-slate-100 hover:border-indigo-200'
                  }`}
                >
                  <span className="font-semibold text-slate-700">{goal}</span>
                  {selectedGoal === goal && <div className="w-4 h-4 rounded-full bg-indigo-600" />}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <button
        onClick={handleNext}
        disabled={(step === 1 && !selectedLang) || (step === 2 && !selectedGoal)}
        className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-200 mb-4"
      >
        <span>{step === 1 ? 'Continue' : 'Start Learning'}</span>
        <ArrowRight size={20} />
      </button>
    </div>
  );
};

export default Onboarding;
