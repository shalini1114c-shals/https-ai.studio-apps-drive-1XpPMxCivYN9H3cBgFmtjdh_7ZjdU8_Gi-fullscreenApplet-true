
import React from 'react';
import { UserProgress, Lesson } from '../types';
import { INITIAL_LESSONS, LANGUAGE_FLAGS } from '../constants';
import { Trophy, Star, BookOpen, PlayCircle, CheckCircle } from 'lucide-react';

interface DashboardProps {
  progress: UserProgress;
  onSelectLesson: (lesson: Lesson) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ progress, onSelectLesson }) => {
  return (
    <div className="pb-24 pt-6 px-6 max-w-md mx-auto space-y-8 overflow-y-auto">
      {/* Header Stat Card */}
      <div className="bg-indigo-600 rounded-3xl p-6 text-white shadow-xl shadow-indigo-100 relative overflow-hidden">
        <div className="relative z-10 flex justify-between items-start">
          <div className="space-y-1">
            <p className="text-indigo-100 font-medium">Daily Goal</p>
            <h2 className="text-3xl font-bold font-outfit">Level {progress.level}</h2>
          </div>
          <div className="bg-white/20 p-3 rounded-2xl backdrop-blur-sm">
            <Trophy size={24} className="text-yellow-300" />
          </div>
        </div>
        
        <div className="mt-6 space-y-2 relative z-10">
          <div className="flex justify-between text-sm font-medium">
            <span>XP Progress</span>
            <span>{progress.xp} / {(progress.level + 1) * 100}</span>
          </div>
          <div className="w-full bg-white/20 h-3 rounded-full overflow-hidden">
            <div 
              className="bg-yellow-400 h-full transition-all duration-1000" 
              style={{ width: `${(progress.xp % 100)}%` }}
            />
          </div>
        </div>

        {/* Decorative Circle */}
        <div className="absolute -right-12 -top-12 w-32 h-32 bg-indigo-500 rounded-full opacity-50" />
      </div>

      {/* Language Path */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold text-slate-900 font-outfit">Learning Path</h3>
          <span className="text-sm font-semibold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full uppercase tracking-wider">
            {LANGUAGE_FLAGS[progress.selectedLanguage]} {progress.selectedLanguage}
          </span>
        </div>

        <div className="space-y-4 relative">
          {/* Vertical Connecting Line */}
          <div className="absolute left-[26px] top-6 bottom-6 w-1 bg-slate-100 -z-10" />

          {INITIAL_LESSONS.map((lesson, idx) => {
            const isCompleted = progress.completedLessons.includes(lesson.id);
            const isCurrent = idx === progress.completedLessons.length;
            const isLocked = idx > progress.completedLessons.length;

            return (
              <button
                key={lesson.id}
                disabled={isLocked}
                onClick={() => onSelectLesson(lesson)}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all text-left ${
                  isCurrent 
                    ? 'border-indigo-600 bg-white shadow-lg shadow-indigo-50 ring-2 ring-indigo-50' 
                    : isCompleted
                    ? 'border-emerald-100 bg-emerald-50 opacity-80'
                    : 'border-slate-50 bg-slate-50 text-slate-400'
                }`}
              >
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-sm ${
                  isCurrent ? 'bg-indigo-600 text-white' : 
                  isCompleted ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-400'
                }`}>
                  {isCompleted ? <CheckCircle size={28} /> : 
                   lesson.type === 'vocabulary' ? <BookOpen size={28} /> : 
                   lesson.type === 'grammar' ? <Star size={28} /> : <PlayCircle size={28} />}
                </div>

                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-bold uppercase tracking-wider mb-0.5 ${isCurrent ? 'text-indigo-600' : isCompleted ? 'text-emerald-600' : 'text-slate-400'}`}>
                    {lesson.type} • {lesson.xpReward} XP
                  </p>
                  <h4 className={`text-lg font-bold truncate ${isLocked ? 'text-slate-400' : 'text-slate-900'}`}>{lesson.title}</h4>
                  <p className="text-sm truncate opacity-70">{lesson.description}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
