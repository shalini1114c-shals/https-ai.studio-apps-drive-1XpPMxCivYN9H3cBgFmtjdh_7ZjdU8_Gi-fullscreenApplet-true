
import React from 'react';
import { Home, MessageSquare, BookOpen, User, Flame } from 'lucide-react';
import { UserProgress } from '../types';

interface NavbarProps {
  currentTab: string;
  setTab: (tab: string) => void;
  progress: UserProgress;
}

const Navbar: React.FC<NavbarProps> = ({ currentTab, setTab, progress }) => {
  const navItems = [
    { id: 'home', icon: Home, label: 'Learn' },
    { id: 'chat', icon: MessageSquare, label: 'Tutor' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-6 py-3 flex justify-between items-center z-50">
      {navItems.map((item) => (
        <button
          key={item.id}
          onClick={() => setTab(item.id)}
          className={`flex flex-col items-center gap-1 transition-colors ${
            currentTab === item.id ? 'text-indigo-600' : 'text-slate-400'
          }`}
        >
          <item.icon size={24} />
          <span className="text-[10px] font-medium uppercase tracking-wider">{item.label}</span>
        </button>
      ))}
      <div className="flex items-center gap-1 bg-orange-50 px-3 py-1 rounded-full text-orange-600 font-bold border border-orange-100">
        <Flame size={18} fill="currentColor" />
        <span>{progress.streak}</span>
      </div>
    </nav>
  );
};

export default Navbar;
