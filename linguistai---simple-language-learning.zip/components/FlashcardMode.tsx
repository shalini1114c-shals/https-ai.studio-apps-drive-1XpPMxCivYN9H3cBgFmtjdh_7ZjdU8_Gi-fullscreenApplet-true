
import React, { useState, useEffect } from 'react';
import { ArrowLeft, RefreshCw, Check, X, Volume2, Sparkles, Loader2 } from 'lucide-react';
import { Language, Flashcard, Lesson } from '../types';
import { generateVocabulary } from '../services/geminiService';

interface FlashcardModeProps {
  lesson: Lesson;
  language: Language;
  onBack: () => void;
  onComplete: () => void;
}

const FlashcardMode: React.FC<FlashcardModeProps> = ({ lesson, language, onBack, onComplete }) => {
  const [cards, setCards] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [loading, setLoading] = useState(true);
  const [knownCount, setKnownCount] = useState(0);

  useEffect(() => {
    const loadCards = async () => {
      setLoading(true);
      const data = await generateVocabulary(language, lesson.title);
      setCards(data);
      setLoading(false);
    };
    loadCards();
  }, [language, lesson]);

  const handleFlip = () => setIsFlipped(!isFlipped);

  const handleNext = (known: boolean) => {
    if (known) setKnownCount(prev => prev + 1);
    
    if (currentIndex < cards.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setIsFlipped(false);
    } else {
      onComplete();
    }
  };

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    const langMap: Record<Language, string> = {
      [Language.Spanish]: 'es-ES',
      [Language.French]: 'fr-FR',
      [Language.German]: 'de-DE',
      [Language.Japanese]: 'ja-JP',
      [Language.Korean]: 'ko-KR',
      [Language.Italian]: 'it-IT',
    };
    utterance.lang = langMap[language] || 'en-US';
    window.speechSynthesis.speak(utterance);
  };

  if (loading) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-white p-6 text-center space-y-4">
        <Loader2 className="animate-spin text-indigo-600" size={48} />
        <h2 className="text-xl font-bold font-outfit text-slate-900">Generating Personal Flashcards</h2>
        <p className="text-slate-500">Our AI is hand-picking vocabulary for this lesson...</p>
      </div>
    );
  }

  if (cards.length === 0) {
      return (
        <div className="h-screen flex flex-col items-center justify-center p-10 text-center space-y-4">
          <p className="text-slate-600">Failed to load cards. Please try again.</p>
          <button onClick={onBack} className="px-6 py-2 bg-indigo-600 text-white rounded-xl">Back to Dashboard</button>
        </div>
      );
  }

  const currentCard = cards[currentIndex];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col p-6 max-w-md mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <button onClick={onBack} className="p-2 hover:bg-white rounded-xl shadow-sm transition-all">
          <ArrowLeft size={24} className="text-slate-600" />
        </button>
        <div className="flex-1 px-6">
          <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-indigo-600 transition-all duration-500"
              style={{ width: `${((currentIndex + 1) / cards.length) * 100}%` }}
            />
          </div>
        </div>
        <span className="text-sm font-bold text-slate-400">{currentIndex + 1}/{cards.length}</span>
      </div>

      {/* Card Body */}
      <div className="flex-1 flex flex-col items-center justify-center">
        <div 
          onClick={handleFlip}
          className={`relative w-full aspect-[3/4] max-h-[450px] transition-all duration-500 [transform-style:preserve-3d] cursor-pointer group ${
            isFlipped ? '[transform:rotateY(180deg)]' : ''
          }`}
        >
          {/* Front */}
          <div className="absolute inset-0 bg-white rounded-[2.5rem] shadow-xl shadow-slate-200 border border-slate-100 p-8 flex flex-col items-center justify-center backface-hidden [backface-visibility:hidden]">
            <Sparkles className="text-indigo-600 absolute top-8 right-8" size={24} />
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-indigo-400 mb-2">Word in {language}</span>
            <h2 className="text-4xl font-bold font-outfit text-slate-900 mb-4 text-center">{currentCard.front}</h2>
            <p className="text-lg text-slate-400 font-medium mb-8">/ {currentCard.pronunciation} /</p>
            
            {/* Pronunciation Button */}
            <button 
                onClick={(e) => { e.stopPropagation(); speak(currentCard.front); }}
                className="p-5 bg-indigo-50 text-indigo-600 rounded-full hover:bg-indigo-100 transition-all hover:scale-110 active:scale-95 shadow-sm mb-2"
                aria-label="Listen to pronunciation"
            >
              <Volume2 size={28} />
            </button>
            <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest">Listen</span>

            <div className="absolute bottom-8 flex items-center gap-2 text-slate-300 font-semibold text-sm">
                <RefreshCw size={14} />
                Tap to reveal translation
            </div>
          </div>

          {/* Back */}
          <div className="absolute inset-0 bg-indigo-600 rounded-[2.5rem] shadow-xl shadow-indigo-100 p-8 flex flex-col items-center justify-center [transform:rotateY(180deg)] [backface-visibility:hidden] text-white">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-indigo-200 mb-2">Translation</span>
            <h2 className="text-4xl font-bold font-outfit mb-6 text-center">{currentCard.back}</h2>
            {currentCard.example && (
                <div className="bg-indigo-700/50 p-6 rounded-2xl w-full text-center">
                    <p className="text-sm text-indigo-200 font-bold mb-1 uppercase tracking-wider">Example</p>
                    <p className="text-lg font-medium italic">"{currentCard.example}"</p>
                </div>
            )}
            
            {/* Pronunciation Button on Back Side */}
            <button 
                onClick={(e) => { e.stopPropagation(); speak(currentCard.front); }}
                className="mt-6 p-3 bg-white/10 text-white rounded-full hover:bg-white/20 transition-all"
                aria-label="Listen to pronunciation"
            >
              <Volume2 size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="mt-8 flex gap-4">
        <button 
          onClick={() => handleNext(false)}
          className="flex-1 p-5 bg-white border-2 border-slate-100 rounded-[2rem] text-slate-400 font-bold flex items-center justify-center gap-2 hover:bg-slate-50 transition-all"
        >
          <X size={24} />
          <span>Repeat</span>
        </button>
        <button 
          onClick={() => handleNext(true)}
          className="flex-1 p-5 bg-emerald-500 shadow-lg shadow-emerald-100 rounded-[2rem] text-white font-bold flex items-center justify-center gap-2 hover:bg-emerald-600 transition-all"
        >
          <Check size={24} />
          <span>I know it</span>
        </button>
      </div>
    </div>
  );
};

export default FlashcardMode;
