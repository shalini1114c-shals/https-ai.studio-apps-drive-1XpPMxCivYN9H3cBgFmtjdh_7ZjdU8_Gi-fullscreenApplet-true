
import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, ArrowLeft, Loader2, Volume2 } from 'lucide-react';
import { Language, ChatMessage } from '../types';
import { getTutorResponse } from '../services/geminiService';

interface ChatModeProps {
  language: Language;
  onBack: () => void;
  onComplete: () => void;
}

const ChatMode: React.FC<ChatModeProps> = ({ language, onBack, onComplete }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial greeting
    const startChat = async () => {
      setLoading(true);
      const greeting = await getTutorResponse(language, `Hi! I want to start practicing ${language}. Say something to welcome me.`, []);
      setMessages([{ id: Date.now().toString(), role: 'model', text: greeting }]);
      setLoading(false);
    };
    startChat();
  }, [language]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    const history = messages.map(m => ({ role: m.role, text: m.text }));
    const responseText = await getTutorResponse(language, input, history);

    const botMsg: ChatMessage = { id: Date.now().toString(), role: 'model', text: responseText };
    setMessages(prev => [...prev, botMsg]);
    setLoading(false);

    if (messages.length > 8) {
        onComplete();
    }
  };

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    const langMap: Record<Language, string> = {
      [Language.Spanish]: 'es-ES',
      [Language.French]: 'fr-FR',
      [Language.German]: 'de-DE',
      [Language.Japanese]: 'ja-JP',
      [Language.Korean]: 'ko-KR',
      [Language.Italian]: 'it-IT',
    };
    utterance.lang = langMap[language] || 'en-US';
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50 max-w-md mx-auto">
      {/* Header */}
      <div className="p-4 bg-white border-b border-slate-200 flex items-center gap-4">
        <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-xl">
          <ArrowLeft size={24} className="text-slate-600" />
        </button>
        <div className="flex-1">
          <h2 className="font-bold text-slate-900 font-outfit">AI Language Tutor</h2>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            <span className="text-xs text-slate-500 font-medium">Practicing {language}</span>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex gap-2 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-xl shrink-0 flex items-center justify-center ${
                msg.role === 'user' ? 'bg-indigo-100 text-indigo-600' : 'bg-white border border-slate-200 text-slate-600'
              }`}>
                {msg.role === 'user' ? <User size={18} /> : <Bot size={18} />}
              </div>
              <div className={`p-4 rounded-2xl shadow-sm ${
                msg.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-tr-none' 
                  : 'bg-white text-slate-800 rounded-tl-none border border-slate-100'
              }`}>
                <p className="text-sm font-medium leading-relaxed">{msg.text}</p>
                {msg.role === 'model' && (
                  <button 
                    onClick={() => speak(msg.text)}
                    className="mt-2 p-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 transition-colors"
                  >
                    <Volume2 size={14} />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-200 rounded-2xl p-4 flex gap-2 items-center">
              <Loader2 className="animate-spin text-indigo-600" size={18} />
              <span className="text-sm text-slate-500 font-medium italic">Tutor is thinking...</span>
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Input */}
      <div className="p-4 bg-white border-t border-slate-200 pb-8">
        <div className="flex gap-2 bg-slate-50 p-2 rounded-2xl border border-slate-100 focus-within:border-indigo-600 focus-within:ring-1 focus-within:ring-indigo-100 transition-all">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type in your target language..."
            className="flex-1 bg-transparent border-none focus:outline-none px-3 py-2 text-slate-700 font-medium"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || loading}
            className="p-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 shadow-md shadow-indigo-100"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatMode;
