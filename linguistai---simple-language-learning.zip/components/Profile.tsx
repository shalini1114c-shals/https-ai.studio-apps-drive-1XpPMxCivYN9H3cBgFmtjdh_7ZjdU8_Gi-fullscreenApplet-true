
import React from 'react';
import { UserProgress } from '../types';
import { Settings, Shield, Award, Calendar, ChevronRight } from 'lucide-react';
import { LANGUAGE_FLAGS } from '../constants';

interface ProfileProps {
  progress: UserProgress;
}

const Profile: React.FC<ProfileProps> = ({ progress }) => {
  const stats = [
    { label: 'Total XP', value: progress.xp, icon: Award, color: 'text-yellow-500', bg: 'bg-yellow-50' },
    { label: 'Current Level', value: progress.level, icon: Shield, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    { label: 'Days Active', value: progress.streak, icon: Calendar, color: 'text-orange-500', bg: 'bg-orange-50' },
  ];

  return (
    <div className="pb-24 pt-6 px-6 max-w-md mx-auto space-y-8 overflow-y-auto">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold font-outfit text-slate-900">Profile</h2>
        <button className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
          <Settings size={24} />
        </button>
      </div>

      <div className="flex flex-col items-center gap-3">
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 border-4 border-white shadow-xl">
            <span className="text-4xl font-bold">JD</span>
          </div>
          <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center border-4 border-white">
            <span className="text-xs font-bold">{progress.level}</span>
          </div>
        </div>
        <div className="text-center">
          <h3 className="text-xl font-bold text-slate-900 font-outfit">Jane Doe</h3>
          <p className="text-slate-500 font-medium">Learning {progress.selectedLanguage} {LANGUAGE_FLAGS[progress.selectedLanguage]}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-white p-4 rounded-2xl border border-slate-100 flex flex-col items-center text-center shadow-sm">
            <div className={`p-2 rounded-xl ${stat.bg} ${stat.color} mb-2`}>
              <stat.icon size={20} />
            </div>
            <span className="text-lg font-bold text-slate-900">{stat.value}</span>
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">{stat.label}</span>
          </div>
        ))}
      </div>

      <div className="space-y-4">
        <h4 className="text-lg font-bold text-slate-900 font-outfit">My Milestones</h4>
        <div className="space-y-3">
          {['Beginner Explorer', 'First 100 XP', '7 Day Streak'].map((badge) => (
            <div key={badge} className="bg-white p-4 rounded-2xl border border-slate-100 flex items-center justify-between group cursor-pointer hover:border-indigo-200 transition-all">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-300 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                  <Award size={20} />
                </div>
                <span className="font-semibold text-slate-700">{badge}</span>
              </div>
              <ChevronRight size={18} className="text-slate-300 group-hover:text-indigo-600" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Profile;
